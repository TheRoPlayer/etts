import sys
import json
from pathlib import Path
from urllib.parse import quote_plus

from PyQt6.QtCore import QUrl, Qt
from PyQt6.QtGui import QAction, QKeySequence
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLineEdit, QPushButton, QMessageBox, QTabWidget, QMenu,
    QFileDialog, QInputDialog, QToolButton
)
from PyQt6.QtWebEngineWidgets import QWebEngineView


APP_NAME = "WebBrowse Pro"
DEFAULT_HOME = "https://www.google.com"

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR / "data"
BOOKMARKS_PATH = DATA_DIR / "bookmarks.json"


def ensure_data_files():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not BOOKMARKS_PATH.exists():
        BOOKMARKS_PATH.write_text(json.dumps({
            "bookmarks": [
                {"name": "Google", "url": "https://www.google.com"},
                {"name": "YouTube", "url": "https://www.youtube.com"},
                {"name": "Roblox", "url": "https://www.roblox.com"},
            ]
        }, indent=2), encoding="utf-8")


def load_bookmarks():
    ensure_data_files()
    try:
        obj = json.loads(BOOKMARKS_PATH.read_text(encoding="utf-8"))
        return obj.get("bookmarks", [])
    except Exception:
        return []


def save_bookmarks(bookmarks):
    ensure_data_files()
    BOOKMARKS_PATH.write_text(json.dumps({"bookmarks": bookmarks}, indent=2), encoding="utf-8")


def normalize_url(text: str) -> QUrl:
    t = (text or "").strip()
    if not t:
        return QUrl(DEFAULT_HOME)
    if "://" in t:
        return QUrl(t)
    if "." in t and " " not in t:
        return QUrl("https://" + t)
    return QUrl(f"https://www.google.com/search?q={quote_plus(t)}")


class BrowserTab(QWidget):
    def __init__(self, parent, url: QUrl):
        super().__init__()
        self.parent = parent
        self.web = QWebEngineView()
        self.web.setUrl(url)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.web)

        self.web.urlChanged.connect(self.on_url)
        self.web.titleChanged.connect(self.on_title)

    def on_url(self, url):
        if self.parent.current_tab() is self:
            self.parent.address.setText(url.toString())

    def on_title(self, title):
        i = self.parent.tabs.indexOf(self)
        if i != -1:
            self.parent.tabs.setTabText(i, (title or "New Tab")[:40])


class BrowserWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(1280, 800)

        self.address = QLineEdit()
        self.address.returnPressed.connect(self.go)

        back = QPushButton("←")
        back.clicked.connect(lambda: self.current_web().back())

        forward = QPushButton("→")
        forward.clicked.connect(lambda: self.current_web().forward())

        reloadb = QPushButton("⟳")
        reloadb.clicked.connect(lambda: self.current_web().reload())

        home = QPushButton("⌂")
        home.clicked.connect(lambda: self.current_web().setUrl(QUrl(DEFAULT_HOME)))

        newtab = QPushButton("+")
        newtab.clicked.connect(self.new_tab)

        closetab = QPushButton("×")
        closetab.clicked.connect(self.close_tab)

        go = QPushButton("Go")
        go.clicked.connect(self.go)

        # FIX: Use QToolButton (NOT QPushButton)
        bookmark_btn = QToolButton()
        bookmark_btn.setText("★")
        bookmark_btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)

        self.bookmark_menu = QMenu(self)
        bookmark_btn.setMenu(self.bookmark_menu)

        top = QWidget()
        h = QHBoxLayout(top)
        h.setContentsMargins(8, 8, 8, 8)
        for w in (back, forward, reloadb, home, newtab, closetab):
            h.addWidget(w)
        h.addWidget(self.address, 1)
        h.addWidget(go)
        h.addWidget(bookmark_btn)

        self.tabs = QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab_index)

        root = QWidget()
        v = QVBoxLayout(root)
        v.setContentsMargins(0, 0, 0, 0)
        v.addWidget(top)
        v.addWidget(self.tabs, 1)
        self.setCentralWidget(root)

        self.refresh_bookmarks()
        self.new_tab()

    def current_tab(self):
        return self.tabs.currentWidget()

    def current_web(self):
        return self.current_tab().web

    def new_tab(self, url=None):
        if url is None:
            url = QUrl(DEFAULT_HOME)
        tab = BrowserTab(self, url)
        self.tabs.addTab(tab, "New Tab")
        self.tabs.setCurrentWidget(tab)

    def close_tab_index(self, index):
        if self.tabs.count() > 1:
            w = self.tabs.widget(index)
            self.tabs.removeTab(index)
            w.deleteLater()

    def close_tab(self):
        self.close_tab_index(self.tabs.currentIndex())

    def go(self):
        self.current_web().setUrl(normalize_url(self.address.text()))

    def refresh_bookmarks(self):
        self.bookmark_menu.clear()
        add = QAction("Add current page", self)
        add.triggered.connect(self.add_bookmark)
        self.bookmark_menu.addAction(add)
        self.bookmark_menu.addSeparator()

        for b in load_bookmarks():
            act = QAction(b["name"], self)
            act.triggered.connect(lambda _, u=b["url"]: self.current_web().setUrl(QUrl(u)))
            self.bookmark_menu.addAction(act)

    def add_bookmark(self):
        url = self.current_web().url().toString()
        name, ok = QInputDialog.getText(self, "Bookmark", "Name:")
        if ok:
            bms = load_bookmarks()
            bms.append({"name": name or url, "url": url})
            save_bookmarks(bms)
            self.refresh_bookmarks()


def main():
    ensure_data_files()
    app = QApplication(sys.argv)
    win = BrowserWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
